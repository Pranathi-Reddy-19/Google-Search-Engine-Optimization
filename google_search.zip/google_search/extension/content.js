// const params = new URLSearchParams(window.location.search);
// const query = params.get("q");

// if (query && query.toLowerCase().includes("notes")) {
//   // Create overlay
//   const overlay = document.createElement("div");
//   overlay.id = "student-overlay";
//   overlay.innerHTML = `
//     <h3>📘 Student Notes Helper</h3>
//     <p><b>Query:</b> ${query}</p>
//     <div id="links">Loading suggestions...</div>
//   `;
//   document.body.appendChild(overlay);

//   // Fetch data from backend
//   fetch(`http://localhost:5000/api/links?query=${encodeURIComponent(query)}`)
//     .then(res => res.json())
//     .then(data => {
//       const linksDiv = document.getElementById("links");
//       if (data.length === 0) {
//         linksDiv.innerHTML = "<p>No student-rated links yet. Be the first to add!</p>";
//       } else {
//         linksDiv.innerHTML = "";
//         data.forEach(link => {
//           const div = document.createElement("div");
//           div.className = "link-item";
//           div.innerHTML = `
//             <a href="${link.url}" target="_blank">${link.url}</a>
//             <p>👍 ${link.upvotes} | 👎 ${link.downvotes}</p>
//             <button class="upvote">👍 Upvote</button>
//             <button class="downvote">👎 Downvote</button>
//           `;
//           linksDiv.appendChild(div);

//           // Add event listeners for voting
//           div.querySelector(".upvote").addEventListener("click", () => rateLink(link.url, query, "up"));
//           div.querySelector(".downvote").addEventListener("click", () => rateLink(link.url, query, "down"));
//         });
//       }
//     })
//     .catch(err => {
//       document.getElementById("links").innerHTML = `<p>Error fetching links: ${err}</p>`;
//     });
// }

// // Function to send rating
// function rateLink(url, query, rating) {
//   fetch("http://localhost:5000/api/rate", {
//     method: "POST",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify({ url, query, rating })
//   })
//     .then(res => res.json())
//     .then(data => {
//       alert(`Thanks! Your ${rating}vote was recorded.`);
//       location.reload(); // refresh overlay to update counts
//     })
//     .catch(err => console.error("Error:", err));
// }

(() => {
  const API_BASE = "http://localhost:5000"; // change to prod URL when deployed

  // --- utils ---
  const $ = (sel, parent = document) => parent.querySelector(sel);
  const create = (tag, props = {}) => Object.assign(document.createElement(tag), props);
  const isValidUrl = (val) => {
    try { new URL(val); return true; } catch { return false; }
  };

  // get Google query
  const params = new URLSearchParams(window.location.search);
  const query = params.get("q");
  if (!query) return;

  // --- overlay UI ---
  const overlay = create("div", { id: "student-overlay" });
  overlay.innerHTML = `
    <h3>📘 Student Notes Helper</h3>
    <p><b>Query:</b> <span id="sn-query"></span></p>

    <div id="sn-add">
      <input id="sn-url" type="text" placeholder="Paste a good link (https://…)" />
      <button id="sn-add-btn">+ Add Link</button>
      <div id="sn-msg" aria-live="polite"></div>
    </div>

    <hr />
    <div id="sn-links">⏳ Loading suggestions…</div>
  `;
  document.body.appendChild(overlay);
  $("#sn-query").textContent = query;

  // --- handlers ---
  $("#sn-add-btn").addEventListener("click", async () => {
    const url = $("#sn-url").value.trim();
    const msg = $("#sn-msg");

    if (!url) { msg.textContent = "Paste a URL first."; return; }
    if (!isValidUrl(url)) { msg.textContent = "That doesn’t look like a valid URL."; return; }

    // optimistic UI
    $("#sn-add-btn").disabled = true;
    $("#sn-add-btn").textContent = "Adding…";
    msg.textContent = "";

    try {
      const res = await fetch(`${API_BASE}/api/addLink`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, query })
      });

      const data = await res.json();

      if (!res.ok) {
        msg.textContent = data?.error || "Couldn’t add link.";
      } else {
        msg.textContent = "✅ Added!";
        $("#sn-url").value = "";
        await renderLinks(); // refresh list
      }
    } catch (e) {
      console.error(e);
      msg.textContent = "Network error adding link.";
    } finally {
      $("#sn-add-btn").disabled = false;
      $("#sn-add-btn").textContent = "+ Add Link";
    }
  });

  async function rateLink(url, rating) {
    try {
      const res = await fetch(`${API_BASE}/api/rate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, query, rating, user: "guest" })
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data?.error || "Couldn’t record vote.");
        return;
      }
      await renderLinks(); // refresh counts
    } catch (e) {
      console.error(e);
      alert("Network error while voting.");
    }
  }

  async function renderLinks() {
    const box = $("#sn-links");
    box.textContent = "⏳ Loading…";
    try {
      const res = await fetch(`${API_BASE}/api/links?query=${encodeURIComponent(query)}`);
      const links = await res.json();

      if (!Array.isArray(links) || links.length === 0) {
        box.innerHTML = `<p>No student-rated links yet. Paste a good one above ↑</p>`;
        return;
      }

      // build list
      box.innerHTML = "";
      links.forEach(link => {
        const item = create("div", { className: "sn-link" });
        item.innerHTML = `
          <a href="${link.url}" target="_blank" rel="noopener">${link.url}</a>
          <div class="sn-votes">
            <span>👍 <b>${link.upvotes || 0}</b> | 👎 <b>${link.downvotes || 0}</b></span>
            <div class="sn-actions">
              <button class="sn-up">👍 Upvote</button>
              <button class="sn-down">👎 Downvote</button>
            </div>
          </div>
        `;
        item.querySelector(".sn-up").addEventListener("click", () => rateLink(link.url, "up"));
        item.querySelector(".sn-down").addEventListener("click", () => rateLink(link.url, "down"));
        box.appendChild(item);
      });
    } catch (e) {
      console.error(e);
      box.innerHTML = `<p>⚠️ Error fetching links.</p>`;
    }
  }

  renderLinks();
})();

